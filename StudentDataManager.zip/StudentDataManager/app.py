import os
import json
import logging
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
import tempfile

# Configure logging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default_secret_key_for_development")

# JSON file path for data storage
DATA_FILE = 'students.json'

def load_students():
    """Load students data from JSON file"""
    try:
        if os.path.exists(DATA_FILE):
            with open(DATA_FILE, 'r') as f:
                return json.load(f)
        return []
    except Exception as e:
        logging.error(f"Error loading students data: {e}")
        return []

def save_students(students):
    """Save students data to JSON file"""
    try:
        with open(DATA_FILE, 'w') as f:
            json.dump(students, f, indent=2)
        return True
    except Exception as e:
        logging.error(f"Error saving students data: {e}")
        return False

def get_next_id():
    """Get the next available ID for a new student"""
    students = load_students()
    if not students:
        return 1
    return max(student.get('id', 0) for student in students) + 1

@app.route('/')
def index():
    """Home page"""
    return render_template('index.html')

@app.route('/add_student', methods=['GET', 'POST'])
def add_student():
    """Add a new student"""
    if request.method == 'POST':
        try:
            # Get form data
            name = request.form.get('name', '').strip()
            class_name = request.form.get('class', '').strip()
            roll_number = request.form.get('roll_number', '').strip()
            caste = request.form.get('caste', '').strip()
            gender = request.form.get('gender', '').strip()
            admission_year = request.form.get('admission_year', '').strip()
            
            # Validate required fields
            if not all([name, class_name, roll_number, caste, gender, admission_year]):
                flash('All fields are required!', 'error')
                return render_template('add_student.html')
            
            # Validate admission year
            try:
                year = int(admission_year)
                current_year = datetime.now().year
                if year < 1900 or year > current_year + 1:
                    flash('Please enter a valid admission year!', 'error')
                    return render_template('add_student.html')
            except ValueError:
                flash('Please enter a valid admission year!', 'error')
                return render_template('add_student.html')
            
            # Load existing students
            students = load_students()
            
            # Check for duplicate roll number in the same class
            for student in students:
                if student.get('roll_number') == roll_number and student.get('class') == class_name:
                    flash('A student with this roll number already exists in this class!', 'error')
                    return render_template('add_student.html')
            
            # Create new student record
            new_student = {
                'id': get_next_id(),
                'name': name,
                'class': class_name,
                'roll_number': roll_number,
                'caste': caste,
                'gender': gender,
                'admission_year': int(admission_year),
                'created_at': datetime.now().isoformat()
            }
            
            # Add to students list
            students.append(new_student)
            
            # Save to file
            if save_students(students):
                flash('Student added successfully!', 'success')
                return redirect(url_for('view_students'))
            else:
                flash('Error saving student data!', 'error')
                
        except Exception as e:
            logging.error(f"Error adding student: {e}")
            flash('An error occurred while adding the student!', 'error')
    
    return render_template('add_student.html')

@app.route('/view_students')
def view_students():
    """View all students"""
    students = load_students()
    return render_template('view_students.html', students=students)

@app.route('/edit_student/<int:student_id>', methods=['GET', 'POST'])
def edit_student(student_id):
    """Edit a student record"""
    students = load_students()
    student = None
    
    # Find the student
    for s in students:
        if s.get('id') == student_id:
            student = s
            break
    
    if not student:
        flash('Student not found!', 'error')
        return redirect(url_for('view_students'))
    
    if request.method == 'POST':
        try:
            # Get form data
            name = request.form.get('name', '').strip()
            class_name = request.form.get('class', '').strip()
            roll_number = request.form.get('roll_number', '').strip()
            caste = request.form.get('caste', '').strip()
            gender = request.form.get('gender', '').strip()
            admission_year = request.form.get('admission_year', '').strip()
            
            # Validate required fields
            if not all([name, class_name, roll_number, caste, gender, admission_year]):
                flash('All fields are required!', 'error')
                return render_template('edit_student.html', student=student)
            
            # Validate admission year
            try:
                year = int(admission_year)
                current_year = datetime.now().year
                if year < 1900 or year > current_year + 1:
                    flash('Please enter a valid admission year!', 'error')
                    return render_template('edit_student.html', student=student)
            except ValueError:
                flash('Please enter a valid admission year!', 'error')
                return render_template('edit_student.html', student=student)
            
            # Check for duplicate roll number in the same class (excluding current student)
            for s in students:
                if (s.get('id') != student_id and 
                    s.get('roll_number') == roll_number and 
                    s.get('class') == class_name):
                    flash('A student with this roll number already exists in this class!', 'error')
                    return render_template('edit_student.html', student=student)
            
            # Update student record
            student.update({
                'name': name,
                'class': class_name,
                'roll_number': roll_number,
                'caste': caste,
                'gender': gender,
                'admission_year': int(admission_year),
                'updated_at': datetime.now().isoformat()
            })
            
            # Save to file
            if save_students(students):
                flash('Student updated successfully!', 'success')
                return redirect(url_for('view_students'))
            else:
                flash('Error updating student data!', 'error')
                
        except Exception as e:
            logging.error(f"Error updating student: {e}")
            flash('An error occurred while updating the student!', 'error')
    
    return render_template('edit_student.html', student=student)

@app.route('/delete_student/<int:student_id>')
def delete_student(student_id):
    """Delete a student record"""
    try:
        students = load_students()
        original_count = len(students)
        
        # Remove the student
        students = [s for s in students if s.get('id') != student_id]
        
        if len(students) < original_count:
            if save_students(students):
                flash('Student deleted successfully!', 'success')
            else:
                flash('Error deleting student data!', 'error')
        else:
            flash('Student not found!', 'error')
            
    except Exception as e:
        logging.error(f"Error deleting student: {e}")
        flash('An error occurred while deleting the student!', 'error')
    
    return redirect(url_for('view_students'))

@app.route('/search_students', methods=['GET', 'POST'])
def search_students():
    """Search and filter students"""
    students = []
    search_performed = False
    
    if request.method == 'POST':
        search_performed = True
        try:
            all_students = load_students()
            search_name = request.form.get('search_name', '').strip().lower()
            search_class = request.form.get('search_class', '').strip().lower()
            search_caste = request.form.get('search_caste', '').strip().lower()
            
            # Filter students based on search criteria
            for student in all_students:
                match = True
                
                if search_name and search_name not in student.get('name', '').lower():
                    match = False
                
                if search_class and search_class not in student.get('class', '').lower():
                    match = False
                
                if search_caste and search_caste not in student.get('caste', '').lower():
                    match = False
                
                if match:
                    students.append(student)
                    
        except Exception as e:
            logging.error(f"Error searching students: {e}")
            flash('An error occurred while searching!', 'error')
    
    return render_template('search_students.html', students=students, search_performed=search_performed)

@app.route('/export_excel')
def export_excel():
    """Export all student data to Excel file"""
    try:
        students = load_students()
        
        if not students:
            flash('No student data to export!', 'warning')
            return redirect(url_for('view_students'))
        
        # Create a new workbook and select the active worksheet
        wb = Workbook()
        ws = wb.active
        ws.title = "Shri Shivaji College Students"
        
        # Define headers
        headers = ['S.No.', 'Name', 'Class', 'Roll Number', 'Gender', 'Caste Category', 'Admission Year', 'Created Date']
        
        # Apply styling to headers
        header_font = Font(bold=True, color="FFFFFF")
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_alignment = Alignment(horizontal="center", vertical="center")
        border = Border(
            left=Side(style="thin"),
            right=Side(style="thin"),
            top=Side(style="thin"),
            bottom=Side(style="thin")
        )
        
        # Add headers
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_alignment
            cell.border = border
        
        # Add student data
        for row, student in enumerate(students, 2):
            # S.No.
            ws.cell(row=row, column=1, value=row-1)
            
            # Name
            ws.cell(row=row, column=2, value=student.get('name', ''))
            
            # Class
            ws.cell(row=row, column=3, value=student.get('class', ''))
            
            # Roll Number
            ws.cell(row=row, column=4, value=student.get('roll_number', ''))
            
            # Gender
            ws.cell(row=row, column=5, value=student.get('gender', ''))
            
            # Caste
            ws.cell(row=row, column=6, value=student.get('caste', ''))
            
            # Admission Year
            ws.cell(row=row, column=7, value=student.get('admission_year', ''))
            
            # Created Date
            created_at = student.get('created_at', '')
            if created_at:
                # Format the datetime string for better readability
                try:
                    dt = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
                    formatted_date = dt.strftime('%Y-%m-%d %H:%M:%S')
                    ws.cell(row=row, column=8, value=formatted_date)
                except:
                    ws.cell(row=row, column=8, value=created_at)
            else:
                ws.cell(row=row, column=8, value='N/A')
            
            # Apply border to data cells
            for col in range(1, len(headers) + 1):
                ws.cell(row=row, column=col).border = border
        
        # Auto-adjust column widths
        for col in range(1, len(headers) + 1):
            column_letter = get_column_letter(col)
            max_length = 0
            for row in ws[column_letter]:
                try:
                    if len(str(row.value)) > max_length:
                        max_length = len(str(row.value))
                except:
                    pass
            # Set minimum width and add some padding
            adjusted_width = max(max_length + 2, 12)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        # Add summary information
        summary_row = len(students) + 3
        ws.cell(row=summary_row, column=1, value="Summary Statistics:")
        ws.cell(row=summary_row, column=1).font = Font(bold=True)
        
        summary_row += 1
        ws.cell(row=summary_row, column=1, value=f"Total Students: {len(students)}")
        
        # Count by gender
        gender_counts = {}
        for student in students:
            gender = student.get('gender', 'Unknown')
            gender_counts[gender] = gender_counts.get(gender, 0) + 1
        
        summary_row += 1
        for gender, count in gender_counts.items():
            ws.cell(row=summary_row, column=1, value=f"{gender}: {count}")
            summary_row += 1
        
        # Count by class
        class_counts = {}
        for student in students:
            class_name = student.get('class', 'Unknown')
            class_counts[class_name] = class_counts.get(class_name, 0) + 1
        
        summary_row += 1
        ws.cell(row=summary_row, column=1, value="Class Distribution:")
        ws.cell(row=summary_row, column=1).font = Font(bold=True)
        summary_row += 1
        
        for class_name, count in class_counts.items():
            ws.cell(row=summary_row, column=1, value=f"{class_name}: {count}")
            summary_row += 1
        
        # Create temporary file
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx')
        wb.save(temp_file.name)
        temp_file.close()
        
        # Generate filename with current date
        current_date = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f'Shri_Shivaji_College_Students_{current_date}.xlsx'
        
        # Send file to user
        return send_file(
            temp_file.name,
            as_attachment=True,
            download_name=filename,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
        
    except Exception as e:
        logging.error(f"Error exporting to Excel: {e}")
        flash('Error occurred while exporting data to Excel!', 'error')
        return redirect(url_for('view_students'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
